import SwiftUI
import WebKit

struct ContentView: UIViewRepresentable {
 func makeCoordinator() -> Coordinator { Coordinator() }
 func makeUIView(context: Context) -> WKWebView {
  let config=WKWebViewConfiguration()
  let nativeFlag = WKUserScript(source:"window.__FTH_IOS_NATIVE__=true;window.__FTH_DISABLE_WEBAUDIO__=true;", injectionTime:.atDocumentStart, forMainFrameOnly:true)
  config.userContentController.addUserScript(nativeFlag)
  config.userContentController.add(context.coordinator,name:"nativeAudio")
  config.allowsInlineMediaPlayback=true
  config.mediaTypesRequiringUserActionForPlayback=[]
  let web=WKWebView(frame:.zero,configuration:config)
  web.scrollView.contentInsetAdjustmentBehavior = .never
  if let url=Bundle.main.url(forResource:"index",withExtension:"html",subdirectory:"Web"){
   web.loadFileURL(url,allowingReadAccessTo:url.deletingLastPathComponent())
  }
  return web
 }
 func updateUIView(_ uiView:WKWebView,context:Context){}
 final class Coordinator:NSObject,WKScriptMessageHandler {
  private func dbl(_ d:[String:Any], _ key:String, _ fallback:Double)->Double {
   (d[key] as? NSNumber)?.doubleValue ?? fallback
  }
  private func intv(_ d:[String:Any], _ key:String, _ fallback:Int)->Int {
   (d[key] as? NSNumber)?.intValue ?? fallback
  }
  func userContentController(_ u:WKUserContentController,didReceive message:WKScriptMessage){
   guard let d=message.body as? [String:Any],let action=d["action"] as? String else{return}
   switch action {
    case "start":
     PlaybackCoordinator.shared.play()
    case "clear": NativeAudioEngine.shared.clear()
    case "saveProfile": PlaybackCoordinator.shared.save()
    case "restoreProfile":
     PlaybackCoordinator.shared.restoreAndPlay()
    case "add":
     NativeAudioEngine.shared.add(type:d["type"] as? String ?? "sine",
      frequency:dbl(d,"frequency",7700), volume:dbl(d,"volume",0.07),
      band:dbl(d,"band",900), pulse:dbl(d,"pulse",0))
    case "stop": PlaybackCoordinator.shared.stop()
    case "dtPlay":
     let ok=DtSoundPlayer.shared.play()
     message.webView?.evaluateJavaScript("window.__FTH_DT_AVAILABLE__=\(ok ? "true":"false");window.dispatchEvent(new CustomEvent('fth-dt-status',{detail:{available:\(ok ? "true":"false")}}));")
    case "dtStop": DtSoundPlayer.shared.stop()
    case "dtVolume": DtSoundPlayer.shared.setVolume(dbl(d,"value",0.18))
    case "frequency": NativeAudioEngine.shared.setFrequency(dbl(d,"value",7700))
    case "bandwidth": NativeAudioEngine.shared.setBandwidth(dbl(d,"value",900))
    case "pulse": NativeAudioEngine.shared.setPulse(dbl(d,"value",0))
    case "volume": NativeAudioEngine.shared.master=dbl(d,"value",0.75)
    case "pan": NativeAudioEngine.shared.pan=dbl(d,"value",0)
    case "dtPan": DtSoundPlayer.shared.setPan(dbl(d,"value",0))
    case "timer": NativeAudioEngine.shared.timer(minutes:intv(d,"minutes",0))
    default: break
   }
  }
 }
}