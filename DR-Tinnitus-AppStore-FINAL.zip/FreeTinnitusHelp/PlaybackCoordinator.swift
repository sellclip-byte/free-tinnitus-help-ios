import Foundation
import MediaPlayer

final class PlaybackCoordinator {
 static let shared=PlaybackCoordinator()
 private(set) var isPlaying=false
 private init(){}

 func play(){
  guard NativeAudioEngine.shared.hasLayers else{return}
  NativeAudioEngine.shared.start()
  isPlaying=true
  NowPlayingManager.shared.update(title:"DR Tinnitus", playing:true)
 }
 func stop(){
  NativeAudioEngine.shared.stop()
  DtSoundPlayer.shared.stop()
  isPlaying=false
  NowPlayingManager.shared.update(title:"DR Tinnitus", playing:false)
 }
 func save(){ NativeAudioEngine.shared.saveProfile() }
 func restoreAndPlay(){
  if NativeAudioEngine.shared.restoreProfile(){ play() }
 }
}