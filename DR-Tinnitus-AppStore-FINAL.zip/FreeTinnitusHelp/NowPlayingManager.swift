import MediaPlayer

final class NowPlayingManager {
 static let shared=NowPlayingManager()
 private init(){
  let c=MPRemoteCommandCenter.shared()
  c.playCommand.addTarget{_ in PlaybackCoordinator.shared.play(); return .success}
  c.pauseCommand.addTarget{_ in PlaybackCoordinator.shared.stop(); return .success}
  c.stopCommand.addTarget{_ in PlaybackCoordinator.shared.stop(); return .success}
  c.nextTrackCommand.isEnabled=false
  c.previousTrackCommand.isEnabled=false
  c.changePlaybackPositionCommand.isEnabled=false
 }
 func update(title:String="DR Tinnitus",playing:Bool=true){
  MPNowPlayingInfoCenter.default().nowPlayingInfo=[
   MPMediaItemPropertyTitle:title,
   MPMediaItemPropertyArtist:"Personalized tinnitus sound",
   MPNowPlayingInfoPropertyPlaybackRate: playing ? 1.0 : 0.0,
   MPNowPlayingInfoPropertyElapsedPlaybackTime:0.0
  ]
 }
}