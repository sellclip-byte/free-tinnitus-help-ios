import AVFoundation
import Foundation

final class NativeAudioEngine {
 static let shared=NativeAudioEngine()
 struct Layer {
  var type:String; var frequency:Double; var volume:Double; var band:Double; var pulse:Double
  var phase:Double=0; var phase2:Double=0; var noiseState:Double=0
 }
 private let engine=AVAudioEngine()
 private var source:AVAudioSourceNode?
 private let lock=NSLock()
 private var layers:[Layer]=[]
 var master:Double=0.65
 var pan:Double=0
 private var stopTimer:Timer?
 private var wasPlayingBeforeInterruption=false

 private init(){
  configureSession()
  NotificationCenter.default.addObserver(self,selector:#selector(interruption(_:)),name:AVAudioSession.interruptionNotification,object:nil)
  NotificationCenter.default.addObserver(self,selector:#selector(routeChanged(_:)),name:AVAudioSession.routeChangeNotification,object:nil)
 }
 private func configureSession(){
  let s=AVAudioSession.sharedInstance()
  try? s.setCategory(.playback,mode:.default,options:[.allowBluetoothA2DP])
  try? s.setActive(true,options:[])
 }
 func clear(){lock.lock();layers.removeAll();lock.unlock()}
 var hasLayers:Bool { lock.lock(); defer{lock.unlock()}; return !layers.isEmpty }
 func add(type:String,frequency:Double,volume:Double,band:Double=900,pulse:Double=0){
  lock.lock();layers.append(Layer(type:type,frequency:frequency,volume:min(0.18,max(0,volume)),band:band,pulse:pulse));lock.unlock()
 }
 func setFrequency(_ v:Double){lock.lock();for i in layers.indices{layers[i].frequency=min(16000,max(100,v))};lock.unlock()}
 func setBandwidth(_ v:Double){lock.lock();for i in layers.indices{layers[i].band=min(8000,max(20,v))};lock.unlock()}
 func setPulse(_ v:Double){lock.lock();for i in layers.indices{layers[i].pulse=min(30,max(0,v))};lock.unlock()}


 func saveProfile(){
  lock.lock()
  let saved=layers.map{SavedLayer(type:$0.type,frequency:$0.frequency,volume:$0.volume,band:$0.band,pulse:$0.pulse)}
  let p=SavedAudioProfile(layers:saved,master:master,pan:pan)
  lock.unlock()
  AudioProfileStore.shared.save(p)
 }
 func restoreProfile()->Bool{
  guard let p=AudioProfileStore.shared.load() else{return false}
  lock.lock()
  layers=p.layers.map{Layer(type:$0.type,frequency:$0.frequency,volume:$0.volume,band:$0.band,pulse:$0.pulse)}
  master=p.master;pan=p.pan
  lock.unlock()
  return true
 }

 func start(){
  NowPlayingManager.shared.update(playing:true)
  if engine.isRunning{return}
  configureSession()
  let format=engine.outputNode.inputFormat(forBus:0), sr=format.sampleRate
  var time=0.0
  source=AVAudioSourceNode { [weak self] _,_,frames,list -> OSStatus in
   guard let self=self else{return noErr}
   let abl=UnsafeMutableAudioBufferListPointer(list)
   self.lock.lock();var ls=self.layers;self.lock.unlock()
   for frame in 0..<Int(frames){
    var sum=0.0
    for i in ls.indices {
     var L=ls[i]
     let sine=sin(L.phase), rnd=Double.random(in:-1...1)
     let alpha=min(0.35,max(0.002,L.band/sr))
     L.noiseState += alpha*(rnd-L.noiseState)
     var x=0.0
     switch L.type.lowercased() {
      case "square","buzz","electric": x=sine >= 0 ? 1:-1
      case "triangle","hum": x=2/Double.pi*asin(sine)
      case "white": x=rnd
      case "pink": x=(rnd+L.noiseState*2)/3
      case "brown": L.noiseState=max(-1,min(1,L.noiseState+Double.random(in:-0.04...0.04)));x=L.noiseState
      case "hiss","widehiss","air","steam","static","crackle": x=rnd*0.72+L.noiseState*0.28
      case "narrow": x=(rnd-L.noiseState)*0.75 + sin(L.phase)*0.25
      case "pulse","flutter":
       x=sine*(0.52+0.48*sin(2*Double.pi*time*max(.2,L.pulse)))
      case "warble","waver":
       x=sin(L.phase+0.28*sin(2*Double.pi*time*max(.2,L.pulse)))
      case "dual":
       x=(sine+sin(L.phase2))/2
      case "metallic","glass","shimmer":
       x=(sine+0.42*sin(L.phase2)+0.2*sin(L.phase*2.01))/1.62
      case "fan":
       x=0.68*L.noiseState+0.32*sin(L.phase*0.025)
      case "jet","engine":
       x=0.72*L.noiseState+0.28*sin(L.phase*0.018)
      case "cicada","cricket":
       x=(sine>=0 ? .5:-.5)+.5*sin(L.phase2)
      case "radio","cloud","reference":
       x = .55 * L.noiseState + .45 * sine
      default:x=sine
     }
     sum += x*L.volume
     L.phase += 2*Double.pi*L.frequency/sr
     L.phase2 += 2*Double.pi*(L.frequency*1.018)/sr
     if L.phase>2*Double.pi{L.phase-=2*Double.pi}
     if L.phase2>2*Double.pi{L.phase2-=2*Double.pi}
     ls[i]=L
    }
    let y=Float(max(-0.72,min(0.72,sum*self.master)))
    for b in 0..<abl.count{
     let side=abl.count<2 ? 1.0:(b==0 ? (self.pan>0 ? 1-self.pan:1):(self.pan<0 ? 1+self.pan:1))
     abl[b].mData?.assumingMemoryBound(to:Float.self)[frame]=y*Float(side)
    }
    time += 1/sr
   }
   self.lock.lock()
   if self.layers.count==ls.count { self.layers=ls }
   self.lock.unlock()
   return noErr
  }
  engine.attach(source!);engine.connect(source!,to:engine.mainMixerNode,format:format)
  try? engine.start()
 }
 func stop(){stopTimer?.invalidate();stopTimer=nil;engine.stop();if let s=source{engine.detach(s)};source=nil}
 func timer(minutes:Int){stopTimer?.invalidate();stopTimer=nil;guard minutes>0 else{return};stopTimer=Timer.scheduledTimer(withTimeInterval:Double(minutes*60),repeats:false){_ in DispatchQueue.main.async { self.stop(); DtSoundPlayer.shared.stop() }}}
 @objc private func interruption(_ n:Notification){
  guard let raw=n.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,let type=AVAudioSession.InterruptionType(rawValue:raw) else{return}
  if type == .began {wasPlayingBeforeInterruption=engine.isRunning;engine.pause()}
  else {
   let rawOptions=n.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0
   configureSession()
   if wasPlayingBeforeInterruption && AVAudioSession.InterruptionOptions(rawValue:rawOptions).contains(.shouldResume){try? engine.start()}
   wasPlayingBeforeInterruption=false
  }
 }
 @objc private func routeChanged(_ n:Notification){configureSession()}
}