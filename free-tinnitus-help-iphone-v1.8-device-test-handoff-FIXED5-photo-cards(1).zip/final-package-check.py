from pathlib import Path
import plistlib,re,sys
errs=[]
try: plistlib.load(open("FreeTinnitusHelp/Info.plist","rb"))
except Exception as e: errs.append("Info.plist: "+str(e))
try: plistlib.load(open("FreeTinnitusHelp/PrivacyInfo.xcprivacy","rb"))
except Exception as e: errs.append("Privacy manifest: "+str(e))
s=Path("FreeTinnitusHelp.xcodeproj/project.pbxproj").read_text()
if not re.search(r'rootObject = [A-F0-9]{24}',s): errs.append("Xcode rootObject")
for f in ["OPEN-IN-XCODE.command","IPHONE-TEST-RESULTS.txt","mac-preflight.sh"]:
 if not Path(f).exists(): errs.append("missing "+f)
print("PASS - final iPhone handoff package" if not errs else "\n".join("FAIL - "+x for x in errs))
sys.exit(bool(errs))
