#!/bin/zsh
set -e
cd "$(dirname "$0")"
./mac-preflight.sh
open FreeTinnitusHelp.xcodeproj
