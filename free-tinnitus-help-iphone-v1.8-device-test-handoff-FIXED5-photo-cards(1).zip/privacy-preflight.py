from pathlib import Path
import plistlib,sys
p=Path("FreeTinnitusHelp/PrivacyInfo.xcprivacy")
d=plistlib.load(p.open("rb"))
errs=[]
if d.get("NSPrivacyTracking") is not False: errs.append("tracking must be false")
if d.get("NSPrivacyCollectedDataTypes") != []: errs.append("unexpected collected-data declaration")
entries=d.get("NSPrivacyAccessedAPITypes",[])
u=[x for x in entries if x.get("NSPrivacyAccessedAPIType")=="NSPrivacyAccessedAPICategoryUserDefaults"]
if not u or "CA92.1" not in u[0].get("NSPrivacyAccessedAPITypeReasons",[]): errs.append("UserDefaults CA92.1 missing")
print("PASS - Apple privacy manifest/UserDefaults reason" if not errs else "\n".join("FAIL - "+e for e in errs))
sys.exit(bool(errs))
