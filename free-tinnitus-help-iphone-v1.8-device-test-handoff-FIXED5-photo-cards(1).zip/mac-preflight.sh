#!/bin/zsh
set -e
cd "$(dirname "$0")"
python3 validate-xcode-project.py
python3 swift-sanity.py
python3 audio-engine-audit.py
python3 release-preflight.py
python3 privacy-preflight.py
echo ""
echo "ALL SOURCE PREFLIGHT CHECKS PASSED."
echo "Now open FreeTinnitusHelp.xcodeproj in Xcode and build to the connected iPhone."
