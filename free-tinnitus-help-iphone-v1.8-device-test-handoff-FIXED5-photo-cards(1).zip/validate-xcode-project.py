from pathlib import Path
import re,sys
p=Path("FreeTinnitusHelp.xcodeproj/project.pbxproj")
s=p.read_text()
errors=[]
m=re.search(r'rootObject = ([A-F0-9]{24})',s)
if not m: errors.append("rootObject is not a valid 24-character Xcode object ID")
for f in ["FreeTinnitusHelp/Info.plist","FreeTinnitusHelp/PrivacyInfo.xcprivacy",
          "FreeTinnitusHelp/NativeAudioEngine.swift","FreeTinnitusHelp/Web/index.html"]:
 if not Path(f).exists(): errors.append("missing "+f)
if "UIBackgroundModes" not in Path("FreeTinnitusHelp/Info.plist").read_text():
 errors.append("background audio declaration missing")
if "PrivacyInfo.xcprivacy" not in s:
 errors.append("privacy manifest not wired into Xcode project")
print("PASS - Xcode project structure" if not errors else "\n".join("FAIL - "+x for x in errors))
sys.exit(bool(errors))
