from pathlib import Path
import sys
r=Path(__file__).parent
checks={
"Swift app entry": r/"FreeTinnitusHelp/FreeTinnitusHelpApp.swift",
"Native audio engine": r/"FreeTinnitusHelp/NativeAudioEngine.swift",
"Playback coordinator": r/"FreeTinnitusHelp/PlaybackCoordinator.swift",
"Background audio plist": r/"FreeTinnitusHelp/Info.plist",
"Privacy manifest": r/"FreeTinnitusHelp/PrivacyInfo.xcprivacy",
"App icon catalog": r/"FreeTinnitusHelp/Assets.xcassets/AppIcon.appiconset/Contents.json",
"XcodeGen spec": r/"project.yml",
"Offline web UI": r/"FreeTinnitusHelp/Web/index.html",
}
bad=False
for name,p in checks.items():
 print(("PASS" if p.exists() else "FAIL"), "-", name)
 bad |= not p.exists()
dt=r/"FreeTinnitusHelp/Web/reference-original.mp3"
print(("PASS" if dt.exists() else "WAIT"), "- authentic dt.sound", "(not substituted)" if not dt.exists() else "")
sys.exit(1 if bad else 0)
