#!/bin/zsh
set -e
cd "$(dirname "$0")"
python3 validate-xcode-project.py
command -v xcodebuild >/dev/null || { echo "ERROR: Xcode is required."; exit 2; }
xcodebuild -project FreeTinnitusHelp.xcodeproj -target FreeTinnitusHelp \
  -sdk iphonesimulator -configuration Debug CODE_SIGNING_ALLOWED=NO build
echo "Compile check PASSED. Open FreeTinnitusHelp.xcodeproj and select your connected iPhone."
