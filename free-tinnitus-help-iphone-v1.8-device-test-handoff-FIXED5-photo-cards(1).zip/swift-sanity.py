from pathlib import Path
import re,sys
files=list(Path("FreeTinnitusHelp").glob("*.swift"))
errors=[]
for p in files:
 s=p.read_text()
 if s.count("{")!=s.count("}"): errors.append(f"{p.name}: unbalanced braces")
 if "as? Double" in s and p.name=="ContentView.swift":
  errors.append("ContentView.swift: direct JS Double casts remain")
required=["import AVFoundation","AVAudioSession","AVAudioEngine"]
e=Path("FreeTinnitusHelp/NativeAudioEngine.swift").read_text()
for x in required:
 if x not in e: errors.append("NativeAudioEngine missing "+x)
print("PASS - static Swift sanity checks" if not errors else "\n".join("FAIL - "+e for e in errors))
sys.exit(bool(errors))
