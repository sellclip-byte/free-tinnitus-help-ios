import UIKit
import AVFoundation

final class AppLifecycle: NSObject, UIApplicationDelegate {
 func application(_ application:UIApplication,
  didFinishLaunchingWithOptions launchOptions:[UIApplication.LaunchOptionsKey:Any]?=nil)->Bool {
  let s=AVAudioSession.sharedInstance()
  try? s.setCategory(.playback,mode:.default,options:[.allowBluetoothA2DP])
  try? s.setActive(true)
  UIApplication.shared.beginReceivingRemoteControlEvents()
  return true
 }
 func applicationWillTerminate(_ application:UIApplication){
  PlaybackCoordinator.shared.save()
 }
}