import SwiftUI
@main struct FreeTinnitusHelpApp: App {
 @UIApplicationDelegateAdaptor(AppLifecycle.self) var lifecycle
 init(){ _ = NowPlayingManager.shared; NowPlayingManager.shared.update(playing:false) }
 var body: some Scene { WindowGroup { ContentView() } }
}