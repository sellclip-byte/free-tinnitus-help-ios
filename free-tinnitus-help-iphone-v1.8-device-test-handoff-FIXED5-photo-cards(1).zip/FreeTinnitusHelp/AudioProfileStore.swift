import Foundation

struct SavedLayer: Codable {
 let type:String
 let frequency:Double
 let volume:Double
 let band:Double
 let pulse:Double
}
struct SavedAudioProfile: Codable {
 var layers:[SavedLayer]
 var master:Double
 var pan:Double
}
final class AudioProfileStore {
 static let shared=AudioProfileStore()
 private let key="fth.native.audio.profile.v1"
 func save(_ p:SavedAudioProfile){
  if let d=try? JSONEncoder().encode(p){UserDefaults.standard.set(d,forKey:key)}
 }
 func load()->SavedAudioProfile?{
  guard let d=UserDefaults.standard.data(forKey:key) else{return nil}
  return try? JSONDecoder().decode(SavedAudioProfile.self,from:d)
 }
 func clear(){UserDefaults.standard.removeObject(forKey:key)}
}