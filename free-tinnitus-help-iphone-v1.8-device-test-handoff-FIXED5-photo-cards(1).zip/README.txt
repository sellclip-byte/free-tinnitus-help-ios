Free Tinnitus Help — iPhone Native v1.8 DEVICE-TEST HANDOFF

This package is the handoff from source preparation to physical iPhone testing.

Added:
- Hardened iPhone/iOS Xcode build settings.
- Portrait iPhone orientation declaration.
- OPEN-IN-XCODE.command: runs all preflight checks and opens the project.
- IPHONE-TEST-RESULTS.txt: exact test sheet for the physical device.
- final-package-check.py.

On the Mac:
1. Unzip this folder.
2. Double-click OPEN-IN-XCODE.command.
3. In Xcode select your Apple Development Team.
4. Connect your iPhone, choose it as the destination, and press Run.
5. Test using IPHONE-TEST-RESULTS.txt.

Authentic dt.sound remains absent and has not been replaced.
A signed iPhone binary cannot be produced without Apple's Xcode/signing environment.
