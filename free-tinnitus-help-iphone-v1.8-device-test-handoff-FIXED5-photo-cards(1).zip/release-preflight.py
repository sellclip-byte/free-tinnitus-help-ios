from pathlib import Path
import re,sys,json
R=Path(".")
errors=[]; waits=[]
need=[
"FreeTinnitusHelp.xcodeproj/project.pbxproj",
"FreeTinnitusHelp/FreeTinnitusHelpApp.swift",
"FreeTinnitusHelp/ContentView.swift",
"FreeTinnitusHelp/NativeAudioEngine.swift",
"FreeTinnitusHelp/PlaybackCoordinator.swift",
"FreeTinnitusHelp/Info.plist",
"FreeTinnitusHelp/PrivacyInfo.xcprivacy",
"FreeTinnitusHelp/Assets.xcassets/AppIcon.appiconset/Contents.json",
"FreeTinnitusHelp/Web/index.html",
"FreeTinnitusHelp/Web/native-ios-bridge.js",
]
for f in need:
 if not (R/f).exists(): errors.append("missing "+f)
pbx=(R/"FreeTinnitusHelp.xcodeproj/project.pbxproj").read_text()
if not re.search(r'rootObject = [A-F0-9]{24}',pbx): errors.append("invalid Xcode rootObject")
plist=(R/"FreeTinnitusHelp/Info.plist").read_text()
if "<string>audio</string>" not in plist: errors.append("background audio missing")
html=(R/"FreeTinnitusHelp/Web/index.html").read_text()
if "__FTH_DISABLE_WEBAUDIO__" not in html: errors.append("native WebAudio guard missing")
if not (R/"FreeTinnitusHelp/Web/reference-original.mp3").exists():
 waits.append("authentic dt.sound MP3")
for x in errors: print("FAIL -",x)
if not errors: print("PASS - release-candidate source structure")
for x in waits: print("WAIT -",x,"(not substituted)")
sys.exit(1 if errors else 0)
