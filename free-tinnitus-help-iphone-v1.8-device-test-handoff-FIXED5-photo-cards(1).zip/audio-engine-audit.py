from pathlib import Path
import sys
html=Path("FreeTinnitusHelp/Web/index.html").read_text()
swift=Path("FreeTinnitusHelp/ContentView.swift").read_text()
checks=[
 ("native flag injected at document start", ".atDocumentStart" in swift and "__FTH_DISABLE_WEBAUDIO__" in swift),
 ("native HTML guard present", 'id="ios-native-audio-guard"' in html),
 ("native JS bridge bundled", 'native-ios-bridge.js' in html),
 ("native bridge registered", 'name:"nativeAudio"' in swift),
]
bad=False
for name,ok in checks:
 print(("PASS" if ok else "FAIL"),"-",name); bad|=not ok
sys.exit(1 if bad else 0)
